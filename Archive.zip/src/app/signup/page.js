// "use client";

// import { useState } from "react";
// import { authClient } from "@/lib/auth-client"; 
// import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import {Select,SelectContent,SelectItem,SelectTrigger,SelectValue,} from "@/components/ui/select";
// import { ROLES } from "@/lib/role";
// import { email } from "zod";

// export default function SignUp() {
//   const [form, setForm] = useState({
//     username: "",
//     password: "",
//     role: ROLES.USER,
//   });

//   const handleChange = (field, value) => {
//     setForm(prev => ({ ...prev, [field]: value }));
//   };

//   const handleSubmit = () => {
//     console.log("SIGN UP DATA", form);
//     // call your API here
//   };

//   return (
//     <div className="min-h-screen flex items-center justify-center bg-muted px-4">
//       <Card className="w-full max-w-sm shadow-xl">
//         <CardHeader>
//           <CardTitle className="text-center text-2xl">Create Account</CardTitle>
//           <p className="text-center text-sm text-muted-foreground">
//             Sign up to start managing your todos
//           </p>
//         </CardHeader>

//         <CardContent className="space-y-4">
//                <Input
//             placeholder="Name"
//             value={form.usernam}
//             onChange={e => handleChange("username", e.target.value)}
//           />

//           <Input
//             placeholder="Email"
//             value={form.email}
//             onChange={e => handleChange("email", e.target.value)}
//           />

//           <Input
//             type="password"
//             placeholder="Password"
//             value={form.password}
//             onChange={e => handleChange("password", e.target.value)}
//           />

//           <Select
//             value={form.role}
//             onValueChange={value => handleChange("role", value)}
//           >
//             <SelectTrigger>
//               <SelectValue placeholder="Select role" />
//             </SelectTrigger>
//             <SelectContent>
//               <SelectItem value={ROLES.USER}>User</SelectItem>
//               <SelectItem value={ROLES.MANAGER}>Manager</SelectItem>
//               <SelectItem value={ROLES.ADMIN}>Admin</SelectItem>
//             </SelectContent>
//           </Select>

//           <Button className="w-full" onClick={handleSubmit}>
//             Sign Up
//           </Button>
//         </CardContent>
//       </Card>
//     </div>
//   );
// }





"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ROLES } from "@/lib/role";
import { authClient } from "@/lib/auth-client";
import { useRouter } from "next/navigation";
export default function SignUp() {

    const router = useRouter();

  const [form, setForm] = useState({
    email: "",
    name: "",
    password: "",
    role: ROLES.USER,
  });

  const [loading, setLoading] = useState(false);

  const handleChange = (field, value) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = async () => {
    if (loading) return;

    const { email, name, password, role } = form;

    if (!email || !name || !password) {
      alert("All fields are required");
      return;
    }

    try {
      setLoading(true);

      const image = "image"; 

      const { data } = await authClient.signUp.email(
        {
          email,
          password,
          name,
          image,
          role,
          callbackURL: "/dashboard",
        },
        {
          onRequest: () => {
            // optional: show loader
          },
          onSuccess: () => {
             router.push("/login");
          },
          onError: (ctx) => {
            alert(ctx.error.message);
          },
        },
      );

      console.log("Signup successful:", data);
    } catch (error) {
      console.error("Signup error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted px-4">
      <Card className="w-full max-w-sm shadow-xl">
        <CardHeader>
          <CardTitle className="text-center text-2xl">
            Create Account
          </CardTitle>
          <p className="text-center text-sm text-muted-foreground">
            Sign up to start managing your todos
          </p>
        </CardHeader>

        <CardContent className="space-y-4">
          <Input
            placeholder="Email"
            value={form.email}
            onChange={(e) => handleChange("email", e.target.value)}
          />

          <Input
            placeholder="Name"
            value={form.name}
            onChange={(e) => handleChange("name", e.target.value)}
          />

          <Input
            type="password"
            placeholder="Password"
            value={form.password}
            onChange={(e) => handleChange("password", e.target.value)}
          />

          <Select
            value={form.role}
            onValueChange={(value) => handleChange("role", value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ROLES.USER}>User</SelectItem>
              <SelectItem value={ROLES.MANAGER}>Manager</SelectItem>
              <SelectItem value={ROLES.ADMIN}>Admin</SelectItem>
            </SelectContent>
          </Select>

          <Button
            className="w-full"
            onClick={handleSubmit}
            disabled={loading}
          >
            {loading ? "Signing Up..." : "Sign Up"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}