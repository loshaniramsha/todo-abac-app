// export default function dashboard() {
//     return (
//         <div className="p-6">
//             <h1 className="text-xl font-bold">Welcome to dashboard</h1>
//             <p>Select role for demo (USER / MANAGER / ADMIN)</p>
//         </div>

//     )
// }


"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export default function Dashboard() {
  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome to your dashboard. Select a role for ABAC demo.
        </p>
      </div>

      <Separator />

      {/* Role Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* USER */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              User
              <Badge variant="secondary">USER</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Can view and manage their own todos.
            </p>
            <Button className="w-full">Enter as User</Button>
          </CardContent>
        </Card>

        {/* MANAGER */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Manager
              <Badge variant="outline">MANAGER</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Can view team todos and approve tasks.
            </p>
            <Button variant="secondary" className="w-full">
              Enter as Manager
            </Button>
          </CardContent>
        </Card>

        {/* ADMIN */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Admin
              <Badge variant="destructive">ADMIN</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Full system access and user management.
            </p>
            <Button variant="destructive" className="w-full">
              Enter as Admin
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
